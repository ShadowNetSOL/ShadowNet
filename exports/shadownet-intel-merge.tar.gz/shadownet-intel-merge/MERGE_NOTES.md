# ShadowNet — Intelligence Update Merge

This bundle merges the **wallet scanner** and **GitHub scanner** intelligence
upgrades from our fork into your codebase, while leaving your **X scanner**
(Twitter API v2 / `twitterApi.ts`) completely untouched.

## What's in this bundle

```
artifacts/api-server/src/routes/intelligence.ts    (merged — 1668 lines)
artifacts/api-server/src/lib/
  cache.ts             (new — small in-memory TTL cache)
  history.ts           (new — score & purchase history)
  wallet-archetype.ts  (new — wallet PnL + archetype classification)
  github-trust.ts      (new — scam-pattern, anti-gaming, structural-risk detectors)
  cross-signal.ts      (new — wallet ↔ mint ↔ repo cross-linking)
artifacts/shadownet/src/pages/app/intel.tsx        (merged — 1856 lines)
```

Drop these straight on top of the matching paths in your repo and commit.

## What changed in `intelligence.ts`

Order of route handlers in the merged file:

| Route                          | Source     | Notes                                    |
| ------------------------------ | ---------- | ---------------------------------------- |
| `POST /intelligence/wallet`            | **OURS**   | Adds archetype, scam patterns, cross-signal |
| `POST /intelligence/wallet/onchain`    | **OURS**   | Adds purchase history, score history     |
| `POST /intelligence/x-ca`              | **YOURS**  | Twitter API v2 — left untouched          |
| `POST /intelligence/smart-followers`   | **YOURS**  | Twitter API v2 — left untouched          |
| `POST /intelligence/github-scan`       | **OURS**   | Adds scam/anti-gaming/structural detectors + cross-signal |

Imports added at the top (after your `xScanCache` import):

```ts
import { pushScore, getScoreHistory, recordPurchases, getPurchases } from "../lib/history.js";
import { classifyArchetype, buildPerMintStats, summarisePnl } from "../lib/wallet-archetype.js";
import { detectScamPatterns, detectAntiGaming, detectStructuralRisk, applyTrustAdjustments } from "../lib/github-trust.js";
import { linkWalletMint, linkRepoMint, getCrossSignalsForWallet, getCrossSignalsForRepo, maskWallet } from "../lib/cross-signal.js";
import { cacheGet as memCacheGet, cacheSet } from "../lib/cache.js";
```

The `cacheGet as memCacheGet` alias avoids a name collision with
`xScanCache.cacheGet` (which your X-scanner code keeps using as-is).

All your X-scanner helpers (`clipStr`, `cacheKey`, `cachePut`, etc.) are
preserved. None of the `twitterApi`, `addressExtract`, or `xScanCache` code
is modified.

## What changed in `intel.tsx`

The frontend uses our base (which has all the new wallet/github intel UI)
with **your full X-scanner section spliced in unchanged** — your
`type ChainTag`, `interface MultiChainAddress`, `interface XCAResult`,
`interface SmartFollowersResult`, `const CHAIN_META`, and the entire
`function XAccountScanner()` are kept verbatim.

## Verification

- TypeScript compiles cleanly on the merged frontend (`pnpm --filter
  @workspace/shadownet exec tsc --noEmit` produces zero errors in
  `intel.tsx`).
- TypeScript on the merged backend produces only pre-existing errors
  (`twitterApi`/`addressExtract`/`xScanCache` module resolution and a
  handful of implicit-any warnings in your own `/x-ca` and
  `/smart-followers` handlers — none introduced by this merge).
- No duplicate top-level definitions in either file.
- All five route handlers present in correct order.
