ShadowNet — session changes (apply on top of your existing source tar)

WHAT'S IN HERE
==============
1. artifacts/api-server/src/routes/intelligence.ts
   Adds Helius RPC support + tiered failover (publicnode -> mainnet-beta).
   Replaces batched getParsedTransactions with concurrency-bounded
   singular getParsedTransaction calls. Fixes "0 txs" wallet tracker bug.

2. artifacts/shadownet/public/opengraph.jpg
   (Optional) Refreshed social sharing image.

HOW TO APPLY
============
From the root of your project, just extract this archive — the directory
structure mirrors your project, so files land in the right place:

   tar -xzf shadownet-session-changes.tar.gz

Then on the server that runs api-server, set this env var:
   SOLANA_RPC_URL=https://mainnet.helius-rpc.com/?api-key=YOUR_HELIUS_KEY

Restart the api-server, and the wallet tracker / dev-token analysis
will pull live on-chain data.
