# Objective
Implement the entire feedback list (Tier 1 + Tier 2 + Tier 3) excluding the X/Twitter
fixes (user will handle separately when paid APIs are added).

# Architecture
- New helper modules (api-server/src/lib/) so intelligence.ts doesn't bloat further
- Caching layer is in-memory Map+TTL (Redis later if needed)
- All persistence is in-memory ring-buffer (notes added for users wanting durable history)

# Tasks

### T001: Shared cache + scoring helpers
- artifacts/api-server/src/lib/cache.ts (new) — Map+TTL, keyed get-or-fetch
- artifacts/api-server/src/lib/wallet-archetype.ts (new) — archetype classifier + PnL
- artifacts/api-server/src/lib/github-trust.ts (new) — anti-gaming + scam patterns
- artifacts/api-server/src/lib/history.ts (new) — score ring-buffer per subject
- Acceptance: typecheck clean, modules export pure functions

### T002: Wire helpers into intelligence.ts
- Cache hot calls (sol price, token meta, gh repo, ai summary, ai analysis)
- Add Promise.race timeout to GitHub AI call
- Sanitize DexScreener strings via clipStr
- Compute wallet PnL/win-rate + archetype in /wallet/onchain
- Compute GitHub scam patterns + anti-gaming + owner age in /github-scan
- Push score history; return last N snapshots
- Add copy-trade signal (basic) using token history cache
- Acceptance: typecheck clean, all routes still respond

### T003: Frontend type & UI updates (intel.tsx)
- Extend interfaces with new fields
- Add UI: archetype badge, PnL panel, scam-pattern callouts, owner-age line, sparkline history
- Acceptance: page renders without errors, new sections show real data

### T004: Verify end-to-end
- Restart api-server, run live test against known wallet + a known repo
- Confirm new fields populate
- Code review with architect

### T005: Update tarballs
- Regenerate full source tar AND incremental session-changes tar
