ShadowNet — Scam Detection Fix Bundle
======================================

Contents:
  lib/github-trust.ts          Drop-in replacement for the file at:
                               artifacts/api-server/src/lib/github-trust.ts
  scam-detection-fix.patch     Same change as a git patch (apply with `git apply`)

How to apply (pick ONE):

  Option A — Replace the file:
    cp lib/github-trust.ts <your-repo>/artifacts/api-server/src/lib/github-trust.ts

  Option B — Apply the patch:
    cd <your-repo>
    git apply /path/to/scam-detection-fix.patch

After applying:
  cd artifacts/api-server
  npx tsc --noEmit          # should pass with no errors
  # then restart the API workflow
