ShadowNet — Full Intel Feature Update Bundle
=============================================

This tarball contains EVERY file modified during this session's intel-feature
work. Drop these on top of your existing repo to get all the updates.

Contents (preserving repo paths):
  artifacts/api-server/src/lib/github-trust.ts
      - Severity-tiered scam detection (HIGH/MED/LOW + verdict + confidence)
      - Structural risk: top-contributor share, solo-dev dominance,
        Shannon-entropy of commit messages, fork-of-template detection
      - False-positive guard: defensive-context detection so security docs
        ("never share your seed phrase") aren't flagged as phishing
      - Newness vs. coordinated-fakery penalty split (cap at -15 for new
        honest projects when scam=CLEAN; fakery signals always apply)

  artifacts/api-server/src/lib/cross-signal.ts
      - LRU graph linking wallets <-> repos <-> X mentions
      - Verdict policy: SAME_ENTITY_LIKELY requires all 3 channels;
        2-source matches downgrade to CONVERGENT_INTEREST
      - Memory-leak fix: pruneReverseKey + bucket-trim eviction returns
        the evicted list

  artifacts/api-server/src/routes/intelligence.ts
      - Wires structural risk + cross-signals into github-scan response
      - maskWallet helper applied to wallet+repo cross-signal serialization
        (caller's own wallet preserved on /api/intelligence/wallet)

  artifacts/shadownet/src/pages/app/intel.tsx
      - UI panels: scam verdict tiers, structural risk, cross-signal display
      - Top contributors with per-contributor account ages

  replit.md
      - Documentation of every change above

How to apply:

  cd <your-repo>
  tar -xzf shadownet-session-changes-bundle.tar.gz

  # That's it — the paths inside the tarball mirror your repo layout, so
  # the files land in the right places.

After applying:
  pnpm install
  cd artifacts/api-server && npx tsc --noEmit          # should pass
  cd ../shadownet && npx tsc --noEmit                  # should pass
  # then restart the api-server and shadownet workflows
